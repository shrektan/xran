[![Build Status](https://travis-ci.org/yihui/MSG.svg)](https://travis-ci.org/yihui/MSG)

This is an R package for my Chinese book _Modern Statistical Graphics_.
