par(mfrow = c(3, 3))
for (i in 1:7)
  image(volcano)
# comment
