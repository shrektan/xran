# xfun

[![Build Status](https://travis-ci.org/yihui/xfun.svg)](https://travis-ci.org/yihui/xfun)
[![Coverage status](https://codecov.io/gh/yihui/xfun/branch/master/graph/badge.svg)](https://codecov.io/github/yihui/xfun?branch=master)
[![Downloads from the RStudio CRAN mirror](https://cranlogs.r-pkg.org/badges/grand-total/xfun)](https://cran.r-project.org/package=xfun)

This package contains several utility functions that I frequently use in other packages, and also miscellaneous functions that I use by myself from time to time. For more information, see https://yihui.name/xfun/.
